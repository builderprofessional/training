-- MySQL dump 10.13  Distrib 5.6.25, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: bptraining
-- ------------------------------------------------------
-- Server version	5.6.25-3+deb.sury.org~trusty+1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_bypass_token`
--

DROP TABLE IF EXISTS `auth_bypass_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_bypass_token` (
  `auth_bypass_token_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `auth_user_id` int(11) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `expiration` datetime NOT NULL,
  `remaining_use_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`auth_bypass_token_id`),
  UNIQUE KEY `token` (`token`),
  KEY `date_created` (`date_created`),
  KEY `expiration` (`expiration`),
  KEY `auth_user_id` (`auth_user_id`),
  CONSTRAINT `auth_bypass_token_ibfk_1` FOREIGN KEY (`auth_user_id`) REFERENCES `auth_user` (`auth_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_bypass_token`
--

LOCK TABLES `auth_bypass_token` WRITE;
/*!40000 ALTER TABLE `auth_bypass_token` DISABLE KEYS */;
INSERT INTO `auth_bypass_token` VALUES (1,'2016-01-04 01:07:08','2016-01-04 01:07:08',NULL,'BMQOZnVagOCy9xp9mnQo','SIGNUP',1,'2016-02-04 01:07:08',1),(2,'2016-01-04 01:07:42','2016-01-04 01:07:42',NULL,'HSC6q98NCyKp4qfImf6h','SIGNUP',2,'2016-02-04 01:07:42',1),(3,'2016-01-04 01:08:10','2016-01-04 01:08:10',NULL,'kMFL5Z2O377J7zzQ1JUi','SIGNUP',3,'2016-02-04 01:08:10',1),(4,'2016-01-04 01:09:50','2016-01-04 01:09:49',NULL,'f6GTtfeg6y1TKlCz81GE','SIGNUP',4,'2016-02-04 01:09:49',1),(5,'2016-01-04 01:13:48','2016-01-04 01:13:48',NULL,'zVwQUqYn1k0JnU2lHyd5','SIGNUP',5,'2016-02-04 01:13:48',1);
/*!40000 ALTER TABLE `auth_bypass_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `auth_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `role` varchar(40) NOT NULL,
  `billing_client_id` int(11) DEFAULT NULL,
  `demographic_person_id` int(11) DEFAULT NULL,
  `support_user_role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`auth_user_id`),
  KEY `date_created` (`date_created`),
  KEY `auth_user_ibfk_1` (`billing_client_id`),
  KEY `auth_user_ibfk_2` (`demographic_person_id`),
  KEY `support_user_role_id` (`support_user_role_id`),
  CONSTRAINT `auth_user_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`),
  CONSTRAINT `auth_user_ibfk_2` FOREIGN KEY (`demographic_person_id`) REFERENCES `demographic_person` (`demographic_person_id`),
  CONSTRAINT `auth_user_ibfk_3` FOREIGN KEY (`support_user_role_id`) REFERENCES `support_user_role` (`support_user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'2014-03-21 22:07:18','2014-03-22 03:07:18','dbadmin','iKw+yyYDAaIE9cknw6XdfjaVtHJ7Gqh+o/GYWoVpWN1wNDQcSjc8uqXSBC+yj0KOMwA7RpCKH9weKfJT+7AEHQ==','salt','ROLE_ADMIN',NULL,NULL,NULL),(3,'2016-01-03 02:28:30','2016-01-03 02:28:30','tony.vance@builderprofessional.com','03mo+28cJgWT/xvNsB8fkaGOI661rGExQiqBjluCH//9Lq/BNxqxmKesNxn3i9qopINRNdzW/sG7iO8d7gyPAA==','zhda`M(H>/^TKz:s/dZo#HDN$#uf\"W)(,`JO$;]f$d/ot','ROLE_SUPPORT',NULL,2,1);
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_client`
--

DROP TABLE IF EXISTS `billing_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_client` (
  `billing_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `demographic_company_id` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`billing_client_id`),
  KEY `date_created` (`date_created`),
  KEY `demographic_company_id` (`demographic_company_id`),
  KEY `active` (`active`),
  CONSTRAINT `billing_client_ibfk_1` FOREIGN KEY (`demographic_company_id`) REFERENCES `demographic_company` (`demographic_company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_client`
--

LOCK TABLES `billing_client` WRITE;
/*!40000 ALTER TABLE `billing_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_client_product`
--

DROP TABLE IF EXISTS `billing_client_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_client_product` (
  `billing_client_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) NOT NULL,
  `billing_product_id` int(11) NOT NULL,
  `next_bill_date` date DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `downgrade_allowed_date` date NOT NULL,
  PRIMARY KEY (`billing_client_product_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_client_id` (`billing_client_id`),
  KEY `billing_product_id` (`billing_product_id`),
  KEY `next_bill_date` (`next_bill_date`),
  CONSTRAINT `billing_client_product_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`),
  CONSTRAINT `billing_client_product_ibfk_2` FOREIGN KEY (`billing_product_id`) REFERENCES `billing_product` (`billing_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_client_product`
--

LOCK TABLES `billing_client_product` WRITE;
/*!40000 ALTER TABLE `billing_client_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_client_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_client_product_scheduled_change`
--

DROP TABLE IF EXISTS `billing_client_product_scheduled_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_client_product_scheduled_change` (
  `billing_client_product_scheduled_change_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) NOT NULL,
  `billing_product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`billing_client_product_scheduled_change_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_client_product_scheduled_change_ibfk_1` (`billing_client_id`),
  KEY `billing_client_product_scheduled_change_ibfk_2` (`billing_product_id`),
  CONSTRAINT `billing_client_product_scheduled_change_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`),
  CONSTRAINT `billing_client_product_scheduled_change_ibfk_2` FOREIGN KEY (`billing_product_id`) REFERENCES `billing_product` (`billing_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_client_product_scheduled_change`
--

LOCK TABLES `billing_client_product_scheduled_change` WRITE;
/*!40000 ALTER TABLE `billing_client_product_scheduled_change` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_client_product_scheduled_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_credit`
--

DROP TABLE IF EXISTS `billing_credit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_credit` (
  `billing_credit_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) NOT NULL,
  `billing_payment_method_id` int(11) DEFAULT NULL,
  `billing_credit_type_id` int(11) NOT NULL,
  `amount` bigint(20) NOT NULL,
  PRIMARY KEY (`billing_credit_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_client_id` (`billing_client_id`),
  KEY `amount` (`amount`),
  KEY `billing_payment_method_id` (`billing_payment_method_id`),
  KEY `billing_credit_type_id` (`billing_credit_type_id`),
  CONSTRAINT `billing_credit_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_credit_ibfk_2` FOREIGN KEY (`billing_payment_method_id`) REFERENCES `billing_payment_method` (`billing_payment_method_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_credit_ibfk_3` FOREIGN KEY (`billing_credit_type_id`) REFERENCES `billing_credit_type` (`billing_credit_type_id`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_credit`
--

LOCK TABLES `billing_credit` WRITE;
/*!40000 ALTER TABLE `billing_credit` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_credit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_credit_type`
--

DROP TABLE IF EXISTS `billing_credit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_credit_type` (
  `billing_credit_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`billing_credit_type_id`),
  UNIQUE KEY `code` (`code`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_credit_type`
--

LOCK TABLES `billing_credit_type` WRITE;
/*!40000 ALTER TABLE `billing_credit_type` DISABLE KEYS */;
INSERT INTO `billing_credit_type` VALUES (1,'2014-02-23 20:59:56','2014-02-23 14:59:56','payment','Payment'),(2,'2014-02-23 20:59:56','2014-02-23 14:59:56','issuedcredit','Issued Credit'),(3,'2014-02-23 21:00:05','2014-02-23 15:00:05','discount','Discount');
/*!40000 ALTER TABLE `billing_credit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_debit`
--

DROP TABLE IF EXISTS `billing_debit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_debit` (
  `billing_debit_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) NOT NULL,
  `billing_debit_type_id` int(11) NOT NULL,
  `billing_product_id` int(11) DEFAULT NULL,
  `billing_credit_id` int(11) DEFAULT NULL,
  `billing_parent_debit_id` int(11) DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `tax_amount` bigint(20) DEFAULT NULL,
  `total_amount` bigint(20) NOT NULL,
  PRIMARY KEY (`billing_debit_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_client_id` (`billing_client_id`),
  KEY `billing_credit_id` (`billing_credit_id`),
  KEY `billing_debit_type_id` (`billing_debit_type_id`),
  KEY `billing_parent_debit_id` (`billing_parent_debit_id`),
  KEY `billing_debit_ibfk_6` (`billing_product_id`),
  CONSTRAINT `billing_debit_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_debit_ibfk_2` FOREIGN KEY (`billing_credit_id`) REFERENCES `billing_credit` (`billing_credit_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_debit_ibfk_4` FOREIGN KEY (`billing_debit_type_id`) REFERENCES `billing_debit_type` (`billing_debit_type_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_debit_ibfk_5` FOREIGN KEY (`billing_parent_debit_id`) REFERENCES `billing_debit` (`billing_debit_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_debit_ibfk_6` FOREIGN KEY (`billing_product_id`) REFERENCES `billing_product` (`billing_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_debit`
--

LOCK TABLES `billing_debit` WRITE;
/*!40000 ALTER TABLE `billing_debit` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_debit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_debit_type`
--

DROP TABLE IF EXISTS `billing_debit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_debit_type` (
  `billing_debit_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`billing_debit_type_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_debit_type`
--

LOCK TABLES `billing_debit_type` WRITE;
/*!40000 ALTER TABLE `billing_debit_type` DISABLE KEYS */;
INSERT INTO `billing_debit_type` VALUES (1,'2015-12-26 23:29:43','2014-02-23 16:52:08','PRODUCT','Charge for Product'),(2,'2015-12-26 23:29:43','2015-12-26 23:29:43','OFFSET','Offset');
/*!40000 ALTER TABLE `billing_debit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_attempt`
--

DROP TABLE IF EXISTS `billing_payment_attempt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_payment_attempt` (
  `billing_payment_attempt_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) NOT NULL,
  `billing_payment_method_id` int(11) NOT NULL,
  `billing_payment_attempt_status_id` int(11) NOT NULL,
  `billing_credit_id` int(11) DEFAULT NULL,
  `billing_product_id` int(11) DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `last_four` varchar(20) DEFAULT NULL,
  `expiration_month` int(11) DEFAULT NULL,
  `expiration_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`billing_payment_attempt_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_client_id` (`billing_client_id`),
  KEY `billing_payment_method_id` (`billing_payment_method_id`),
  KEY `billing_payment_attempt_status_id` (`billing_payment_attempt_status_id`),
  KEY `billing_credit_id` (`billing_credit_id`),
  KEY `billing_product_id` (`billing_product_id`),
  CONSTRAINT `billing_payment_attempt_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_payment_attempt_ibfk_2` FOREIGN KEY (`billing_payment_method_id`) REFERENCES `billing_payment_method` (`billing_payment_method_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_payment_attempt_ibfk_3` FOREIGN KEY (`billing_payment_attempt_status_id`) REFERENCES `billing_payment_attempt_status` (`billing_payment_attempt_status_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_payment_attempt_ibfk_4` FOREIGN KEY (`billing_credit_id`) REFERENCES `billing_credit` (`billing_credit_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_payment_attempt_ibfk_5` FOREIGN KEY (`billing_product_id`) REFERENCES `billing_product` (`billing_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_attempt`
--

LOCK TABLES `billing_payment_attempt` WRITE;
/*!40000 ALTER TABLE `billing_payment_attempt` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_payment_attempt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_attempt_status`
--

DROP TABLE IF EXISTS `billing_payment_attempt_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_payment_attempt_status` (
  `billing_payment_attempt_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`billing_payment_attempt_status_id`),
  UNIQUE KEY `code` (`code`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_attempt_status`
--

LOCK TABLES `billing_payment_attempt_status` WRITE;
/*!40000 ALTER TABLE `billing_payment_attempt_status` DISABLE KEYS */;
INSERT INTO `billing_payment_attempt_status` VALUES (1,'2014-02-16 19:13:32','2014-02-16 13:13:32','pending','Pending'),(2,'2014-02-19 03:37:11','2014-02-18 21:37:11','success','Success'),(3,'2015-12-26 23:29:43','2015-12-26 23:29:43','failed','Failed');
/*!40000 ALTER TABLE `billing_payment_attempt_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_method`
--

DROP TABLE IF EXISTS `billing_payment_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_payment_method` (
  `billing_payment_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_key` varchar(255) NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) NOT NULL,
  `billing_payment_method_type_id` int(11) NOT NULL,
  PRIMARY KEY (`billing_payment_method_id`),
  KEY `date_created` (`date_created`),
  KEY `client_id` (`billing_client_id`),
  KEY `billing_payment_method_type_id` (`billing_payment_method_type_id`),
  CONSTRAINT `billing_payment_method_ibfk_2` FOREIGN KEY (`billing_payment_method_type_id`) REFERENCES `billing_payment_method_type` (`billing_payment_method_type_id`) ON UPDATE NO ACTION,
  CONSTRAINT `billing_payment_method_ibfk_3` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_method`
--

LOCK TABLES `billing_payment_method` WRITE;
/*!40000 ALTER TABLE `billing_payment_method` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_payment_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_payment_method_type`
--

DROP TABLE IF EXISTS `billing_payment_method_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_payment_method_type` (
  `billing_payment_method_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `strategy` varchar(255) NOT NULL,
  PRIMARY KEY (`billing_payment_method_type_id`),
  KEY `date_created` (`date_created`),
  KEY `strategy` (`strategy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_payment_method_type`
--

LOCK TABLES `billing_payment_method_type` WRITE;
/*!40000 ALTER TABLE `billing_payment_method_type` DISABLE KEYS */;
INSERT INTO `billing_payment_method_type` VALUES (1,'2014-02-16 16:57:25','2014-02-12 20:56:59','braintree','Braintree Payments','vault');
/*!40000 ALTER TABLE `billing_payment_method_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_product`
--

DROP TABLE IF EXISTS `billing_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_product` (
  `billing_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `description` text,
  `position` int(11) NOT NULL DEFAULT '0',
  `one_time_flag` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`billing_product_id`),
  KEY `date_created` (`date_created`),
  KEY `code` (`code`),
  KEY `amount` (`amount`),
  KEY `position` (`position`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_product`
--

LOCK TABLES `billing_product` WRITE;
/*!40000 ALTER TABLE `billing_product` DISABLE KEYS */;
INSERT INTO `billing_product` VALUES (5,'2016-01-03 22:51:33','2016-01-03 22:51:33','QUICKBOOKS_FOR_HOMEBUILDERS','QuickBooks for Homebuilders',2990000,'',1,1),(6,'2016-01-03 22:51:33','2016-01-03 22:51:33','NEVER_STOP_LEARNING','Never Stop Learning',290000,'',0,0);
/*!40000 ALTER TABLE `billing_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_signup`
--

DROP TABLE IF EXISTS `billing_signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_signup` (
  `billing_signup_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `auth_bypass_token_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  PRIMARY KEY (`billing_signup_id`),
  KEY `date_created` (`date_created`),
  KEY `auth_bypass_token_id` (`auth_bypass_token_id`),
  CONSTRAINT `billing_signup_ibfk_1` FOREIGN KEY (`auth_bypass_token_id`) REFERENCES `auth_bypass_token` (`auth_bypass_token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_signup`
--

LOCK TABLES `billing_signup` WRITE;
/*!40000 ALTER TABLE `billing_signup` DISABLE KEYS */;
INSERT INTO `billing_signup` VALUES (5,'2016-01-04 01:13:48','2016-01-04 01:13:48',5,'James Kirk','anthonytvance@gmail.com','n2QHZQcN/A9n25mexHVTWhdKm4AFl1e/hof53u2bl7HuPmFMkzs7u3aKpM/LuPGqm42JFRZrLbcfYaTRK4mazQ==','?Z+f5dD[tGLr?gLj0g:A0+K,/<s=:=ujJ,y)KQ^U6zwE&');
/*!40000 ALTER TABLE `billing_signup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_strategy_vault`
--

DROP TABLE IF EXISTS `billing_strategy_vault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_strategy_vault` (
  `billing_strategy_vault_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_payment_method_id` int(11) NOT NULL,
  `external_customer_id` varchar(255) NOT NULL,
  `last_four` varchar(20) DEFAULT NULL,
  `expiration_month` int(11) DEFAULT NULL,
  `expiration_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`billing_strategy_vault_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_payment_method_id` (`billing_payment_method_id`),
  CONSTRAINT `billing_strategy_vault_ibfk_1` FOREIGN KEY (`billing_payment_method_id`) REFERENCES `billing_payment_method` (`billing_payment_method_id`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_strategy_vault`
--

LOCK TABLES `billing_strategy_vault` WRITE;
/*!40000 ALTER TABLE `billing_strategy_vault` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_strategy_vault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_address`
--

DROP TABLE IF EXISTS `demographic_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_address` (
  `demographic_address_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(10) DEFAULT NULL,
  `zip_code` varchar(15) DEFAULT NULL,
  `country` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`demographic_address_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_address`
--

LOCK TABLES `demographic_address` WRITE;
/*!40000 ALTER TABLE `demographic_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `demographic_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_company`
--

DROP TABLE IF EXISTS `demographic_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_company` (
  `demographic_company_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `demographic_address_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`demographic_company_id`),
  KEY `date_created` (`date_created`),
  KEY `demographic_company_ibfk_1` (`demographic_address_id`),
  CONSTRAINT `demographic_company_ibfk_1` FOREIGN KEY (`demographic_address_id`) REFERENCES `demographic_address` (`demographic_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_company`
--

LOCK TABLES `demographic_company` WRITE;
/*!40000 ALTER TABLE `demographic_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `demographic_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_email`
--

DROP TABLE IF EXISTS `demographic_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_email` (
  `demographic_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `demographic_person_id` int(11) DEFAULT NULL,
  `demographic_company_id` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`demographic_email_id`),
  KEY `date_created` (`date_created`),
  KEY `demographic_email_ibfk_1` (`demographic_person_id`),
  KEY `demographic_email_ibfk_2` (`demographic_company_id`),
  CONSTRAINT `demographic_email_ibfk_1` FOREIGN KEY (`demographic_person_id`) REFERENCES `demographic_person` (`demographic_person_id`),
  CONSTRAINT `demographic_email_ibfk_2` FOREIGN KEY (`demographic_company_id`) REFERENCES `demographic_company` (`demographic_company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_email`
--

LOCK TABLES `demographic_email` WRITE;
/*!40000 ALTER TABLE `demographic_email` DISABLE KEYS */;
INSERT INTO `demographic_email` VALUES (1,'2016-01-03 02:28:30','2016-01-03 02:28:30',2,NULL,'tony.vance@builderprofessional.com');
/*!40000 ALTER TABLE `demographic_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_employee`
--

DROP TABLE IF EXISTS `demographic_employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_employee` (
  `demographic_employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `demographic_person_id` int(11) NOT NULL,
  `demographic_company_id` int(11) NOT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`demographic_employee_id`),
  KEY `date_created` (`date_created`),
  KEY `demographic_employee_ibfk_1` (`demographic_person_id`),
  KEY `demographic_employee_ibfk_2` (`demographic_company_id`),
  CONSTRAINT `demographic_employee_ibfk_1` FOREIGN KEY (`demographic_person_id`) REFERENCES `demographic_person` (`demographic_person_id`),
  CONSTRAINT `demographic_employee_ibfk_2` FOREIGN KEY (`demographic_company_id`) REFERENCES `demographic_company` (`demographic_company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_employee`
--

LOCK TABLES `demographic_employee` WRITE;
/*!40000 ALTER TABLE `demographic_employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `demographic_employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_person`
--

DROP TABLE IF EXISTS `demographic_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_person` (
  `demographic_person_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `demographic_address_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `suffix` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`demographic_person_id`),
  KEY `date_created` (`date_created`),
  KEY `demographic_person_ibfk_1` (`demographic_address_id`),
  CONSTRAINT `demographic_person_ibfk_1` FOREIGN KEY (`demographic_address_id`) REFERENCES `demographic_address` (`demographic_address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_person`
--

LOCK TABLES `demographic_person` WRITE;
/*!40000 ALTER TABLE `demographic_person` DISABLE KEYS */;
INSERT INTO `demographic_person` VALUES (2,'2016-01-03 02:28:30','2016-01-03 02:28:30',NULL,'Tony',NULL,'Vance',NULL);
/*!40000 ALTER TABLE `demographic_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_phone`
--

DROP TABLE IF EXISTS `demographic_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_phone` (
  `demographic_phone_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `demographic_person_id` int(11) DEFAULT NULL,
  `demographic_company_id` int(11) DEFAULT NULL,
  `number` varchar(40) NOT NULL,
  `demographic_phone_type_id` int(11) NOT NULL,
  PRIMARY KEY (`demographic_phone_id`),
  KEY `date_created` (`date_created`),
  KEY `demographic_phone_ibfk_1` (`demographic_person_id`),
  KEY `demographic_phone_ibfk_2` (`demographic_company_id`),
  KEY `demographic_phone_type_id` (`demographic_phone_type_id`),
  CONSTRAINT `demographic_phone_ibfk_1` FOREIGN KEY (`demographic_person_id`) REFERENCES `demographic_person` (`demographic_person_id`),
  CONSTRAINT `demographic_phone_ibfk_2` FOREIGN KEY (`demographic_company_id`) REFERENCES `demographic_company` (`demographic_company_id`),
  CONSTRAINT `demographic_phone_ibfk_3` FOREIGN KEY (`demographic_phone_type_id`) REFERENCES `demographic_phone_type` (`demographic_phone_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_phone`
--

LOCK TABLES `demographic_phone` WRITE;
/*!40000 ALTER TABLE `demographic_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `demographic_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demographic_phone_type`
--

DROP TABLE IF EXISTS `demographic_phone_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demographic_phone_type` (
  `demographic_phone_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`demographic_phone_type_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demographic_phone_type`
--

LOCK TABLES `demographic_phone_type` WRITE;
/*!40000 ALTER TABLE `demographic_phone_type` DISABLE KEYS */;
INSERT INTO `demographic_phone_type` VALUES (1,'2015-12-26 23:29:43','2015-12-26 23:29:43','Office'),(2,'2015-12-26 23:29:43','2015-12-26 23:29:43','Mobile'),(3,'2015-12-26 23:29:43','2015-12-26 23:29:43','Fax'),(4,'2015-12-26 23:29:43','2015-12-26 23:29:43','Home'),(5,'2015-12-26 23:29:43','2015-12-26 23:29:43','Other');
/*!40000 ALTER TABLE `demographic_phone_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine_tag`
--

DROP TABLE IF EXISTS `engine_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine_tag` (
  `engine_tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`engine_tag_id`),
  KEY `date_created` (`date_created`),
  KEY `billing_client_id` (`billing_client_id`),
  CONSTRAINT `engine_tag_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine_tag`
--

LOCK TABLES `engine_tag` WRITE;
/*!40000 ALTER TABLE `engine_tag` DISABLE KEYS */;
INSERT INTO `engine_tag` VALUES (1,'2015-12-26 23:29:43','2015-12-26 23:29:43',NULL,'Builder'),(2,'2015-12-26 23:29:43','2015-12-26 23:29:43',NULL,'Billing');
/*!40000 ALTER TABLE `engine_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine_tag_item_link`
--

DROP TABLE IF EXISTS `engine_tag_item_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine_tag_item_link` (
  `engine_tag_item_link_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `engine_tag_id` int(11) NOT NULL,
  `engine_tag_system_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`engine_tag_item_link_id`),
  KEY `date_created` (`date_created`),
  KEY `otf_tag_id` (`engine_tag_id`,`item_id`),
  KEY `otf_tag_system_id` (`engine_tag_system_id`),
  CONSTRAINT `engine_tag_item_link_ibfk_1` FOREIGN KEY (`engine_tag_id`) REFERENCES `engine_tag` (`engine_tag_id`) ON UPDATE NO ACTION,
  CONSTRAINT `engine_tag_item_link_ibfk_2` FOREIGN KEY (`engine_tag_system_id`) REFERENCES `engine_tag_system` (`engine_tag_system_id`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine_tag_item_link`
--

LOCK TABLES `engine_tag_item_link` WRITE;
/*!40000 ALTER TABLE `engine_tag_item_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine_tag_item_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine_tag_system`
--

DROP TABLE IF EXISTS `engine_tag_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine_tag_system` (
  `engine_tag_system_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `item_table_name` varchar(255) NOT NULL,
  PRIMARY KEY (`engine_tag_system_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine_tag_system`
--

LOCK TABLES `engine_tag_system` WRITE;
/*!40000 ALTER TABLE `engine_tag_system` DISABLE KEYS */;
INSERT INTO `engine_tag_system` VALUES (1,'2013-12-15 04:53:55','2013-12-14 22:53:55','CLIENT','billing_client'),(2,'2014-03-20 22:08:00','2014-03-20 17:08:00','CREDIT','billing_credit'),(3,'2015-12-26 23:29:43','2015-12-26 23:29:43','EMPLOYEE','demographic_employee');
/*!40000 ALTER TABLE `engine_tag_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_image`
--

DROP TABLE IF EXISTS `media_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_image` (
  `media_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `billing_client_id` int(11) DEFAULT NULL,
  `image_tag_key` varchar(255) NOT NULL,
  `image_tag_id` varchar(255) NOT NULL,
  `extension` varchar(255) NOT NULL,
  `mime_type` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`media_image_id`),
  KEY `date_created` (`date_created`),
  KEY `image_tag_key_id` (`image_tag_key`,`image_tag_id`,`billing_client_id`),
  KEY `media_image_ibfk_1` (`billing_client_id`),
  CONSTRAINT `media_image_ibfk_1` FOREIGN KEY (`billing_client_id`) REFERENCES `billing_client` (`billing_client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_image`
--

LOCK TABLES `media_image` WRITE;
/*!40000 ALTER TABLE `media_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phinxlog_app`
--

DROP TABLE IF EXISTS `phinxlog_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phinxlog_app` (
  `version` bigint(20) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog_app`
--

LOCK TABLES `phinxlog_app` WRITE;
/*!40000 ALTER TABLE `phinxlog_app` DISABLE KEYS */;
INSERT INTO `phinxlog_app` VALUES (20160101222637,'2016-01-03 01:30:02','2016-01-03 01:30:02'),(20160101230518,'2016-01-03 01:30:02','2016-01-03 01:30:02'),(20160101230823,'2016-01-03 01:30:02','2016-01-03 01:30:02'),(20160102153829,'2016-01-03 01:30:02','2016-01-03 01:30:02'),(20160103224456,'2016-01-03 22:51:33','2016-01-03 22:51:33');
/*!40000 ALTER TABLE `phinxlog_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phinxlog_engine`
--

DROP TABLE IF EXISTS `phinxlog_engine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phinxlog_engine` (
  `version` bigint(20) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog_engine`
--

LOCK TABLES `phinxlog_engine` WRITE;
/*!40000 ALTER TABLE `phinxlog_engine` DISABLE KEYS */;
INSERT INTO `phinxlog_engine` VALUES (20151227010943,'2016-01-03 01:30:01','2016-01-03 01:30:02'),(20160102013324,'2016-01-03 01:30:02','2016-01-03 01:30:02'),(20160102152956,'2016-01-03 01:30:02','2016-01-03 01:30:02'),(20160103220818,'2016-01-03 22:09:08','2016-01-03 22:09:08'),(20160103221103,'2016-01-03 22:44:14','2016-01-03 22:44:14');
/*!40000 ALTER TABLE `phinxlog_engine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_definition`
--

DROP TABLE IF EXISTS `report_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_definition` (
  `report_definition_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `class_namespace` varchar(255) NOT NULL,
  `class_bundle` varchar(255) NOT NULL,
  `class_entity` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class_key` varchar(255) NOT NULL,
  PRIMARY KEY (`report_definition_id`),
  KEY `date_created` (`date_created`),
  KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_definition`
--

LOCK TABLES `report_definition` WRITE;
/*!40000 ALTER TABLE `report_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_user_role`
--

DROP TABLE IF EXISTS `support_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_user_role` (
  `support_user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  PRIMARY KEY (`support_user_role_id`),
  KEY `date_created` (`date_created`),
  KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_user_role`
--

LOCK TABLES `support_user_role` WRITE;
/*!40000 ALTER TABLE `support_user_role` DISABLE KEYS */;
INSERT INTO `support_user_role` VALUES (1,'2016-01-03 01:30:02','2016-01-03 01:30:02','Admin','ADMIN');
/*!40000 ALTER TABLE `support_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_answer`
--

DROP TABLE IF EXISTS `training_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_answer` (
  `training_answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `training_question_id` int(11) NOT NULL,
  `auth_user_id` int(11) NOT NULL,
  PRIMARY KEY (`training_answer_id`),
  KEY `date_created` (`date_created`),
  KEY `training_question_id` (`training_question_id`),
  KEY `auth_user_id` (`auth_user_id`),
  CONSTRAINT `training_answer_ibfk_1` FOREIGN KEY (`training_question_id`) REFERENCES `training_question` (`training_question_id`),
  CONSTRAINT `training_answer_ibfk_2` FOREIGN KEY (`auth_user_id`) REFERENCES `auth_user` (`auth_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_answer`
--

LOCK TABLES `training_answer` WRITE;
/*!40000 ALTER TABLE `training_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_course`
--

DROP TABLE IF EXISTS `training_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_course` (
  `training_course_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  PRIMARY KEY (`training_course_id`),
  KEY `date_created` (`date_created`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_course`
--

LOCK TABLES `training_course` WRITE;
/*!40000 ALTER TABLE `training_course` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_question`
--

DROP TABLE IF EXISTS `training_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_question` (
  `training_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime NOT NULL,
  `auth_user_id` int(11) NOT NULL,
  `training_course_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`training_question_id`),
  KEY `date_created` (`date_created`),
  KEY `auth_user_id` (`auth_user_id`),
  KEY `training_course_id` (`training_course_id`),
  CONSTRAINT `training_question_ibfk_1` FOREIGN KEY (`auth_user_id`) REFERENCES `auth_user` (`auth_user_id`),
  CONSTRAINT `training_question_ibfk_2` FOREIGN KEY (`training_course_id`) REFERENCES `training_course` (`training_course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_question`
--

LOCK TABLES `training_question` WRITE;
/*!40000 ALTER TABLE `training_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

